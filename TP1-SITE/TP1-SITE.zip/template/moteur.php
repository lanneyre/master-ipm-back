<?php

include("pages/page0$page.php");
