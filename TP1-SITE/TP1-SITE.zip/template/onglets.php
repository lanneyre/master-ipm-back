<ul>
    <li class="<?php echo $ongletActif == 0 ? "active" : ""; ?>"><a href="index.php">Accueil</a></li>
    <li class="<?php echo $ongletActif == 2 || $ongletActif == 7 ? "active" : ""; ?>"><a href="index.php?page=2">Passer le test</a></li>
    <li class="<?php echo $ongletActif == 1 ? "active" : ""; ?>"><a href="index.php?page=1">Le cours</a></li>
    <li class="<?php echo $ongletActif == 6 ? "active" : ""; ?>"><a href="index.php?page=6">Le TP</a></li>
</ul>