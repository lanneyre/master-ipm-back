<ol>
    <!-- <li>Passer le test :</li>
    <ul>
        <li><a href="index.php?page=2">Test</a></li>
    </ul> -->
    <li>Lire le cours :</li>
    <ul>
        <li><a href="index.php?page=1">Introduction</a></li>
        <li><a href="index.php?page=3">Variables</a></li>
        <li><a href="index.php?page=4">Tableaux</a></li>
        <li><a href="index.php?page=5">Graphiques</a></li>
    </ul>
    <!-- <li>Réaliser le TP</li>
    <ul>
        <li><a href="index.php?page=6">Le TP</a></li>
    </ul> -->
</ol>