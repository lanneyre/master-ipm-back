<p>La séquence présentée est un court extrait du module de cours de statistique
    descriptive destiné aux étudiants de licence de sciences de l'éducation de l'université de Lille 3.<br />
    A l'origine ce cours était déployé sous forme d'un cours magistral et d'un TD intégré de 13 X 3 heures.
    La séquence présentée ici est une reformulation fictive du premier cours et d'un exercice qui était
    initialement destiné à être réalisé à la maison.</p>
<p>Les curieux pourront consulter les <a href="http://pa.caron.free.fr/ipm/cours_stat/">TP réels du cours </a></p>